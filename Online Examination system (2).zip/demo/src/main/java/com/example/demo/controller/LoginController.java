package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Answer;
import com.example.demo.entity.Questions;
import com.example.demo.entity.Student;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller

public class LoginController {

@Autowired


SessionFactory factory;

@RequestMapping("Login")
public String Login()
{
	return "Login"; //here Loginis jsp pagename
}

@RequestMapping("admin")
public String questionmanagement()
{
	return "questionmanagement";  //here questionmanagemnt is jsp page name
}
@RequestMapping("register")
public String registerPage() {
    return "register";  // here register is the JSP page name
}


@RequestMapping("validate")
public ModelAndView validate(String username,String password,HttpServletRequest request)
{
	ModelAndView modelandview =new ModelAndView();
	Session session=factory.openSession();
	Student userfromdb=session.get(Student.class,username);

	if(userfromdb==null) {
		modelandview.setViewName("Login");
		modelandview.addObject("message","wrong username");
	}
	else if(userfromdb.password.equals(password)) {
		modelandview.setViewName("welcome");
		HttpSession httpsession =request.getSession();
		httpsession.setAttribute("username", username);
		}
	else
	{
		modelandview.setViewName("Login");
		modelandview.addObject("message","wrong password");
	}
	return modelandview;
}

@RequestMapping("register2")
public ModelAndView register(String username, String password, long mobno,String emailid, String imagepath, HttpServletRequest request) {
    ModelAndView modelAndView = new ModelAndView();

    // Check if the username already exists
    Session session = factory.openSession();
    Student userFromDb = session.get(Student.class, username);

    if (userFromDb != null) {
        modelAndView.setViewName("register");
        modelAndView.addObject("message", "Username already exists. Choose a different one.");
        return modelAndView;
    }
    else {
        // Create a new user
        Student newUser = new Student(username, password, mobno, emailid, imagepath);
        session.beginTransaction();
        session.save(newUser);
        session.getTransaction().commit();

        modelAndView.setViewName("Login");
        modelAndView.addObject("message", "Registration successful. You can now log in.");
    }

    return modelAndView;
}



@RequestMapping("startExam")
public ModelAndView startExam(String selectedSubject,HttpServletRequest request)
{
	System.out.println(selectedSubject);
	ModelAndView modelAndView=new ModelAndView();

	if(selectedSubject==null) {
		modelAndView.setViewName("Login");
	}else
	{
		Session session=factory.openSession();
		// Criteria is only for fetching record(select query)
		 //HQL is for all operation insert,update,delete,select
		//using add() we add condition,based on which records are fetched from database
		//e.g we want only thoserecord which are having value maths for subject
		//seelct * fromQuestions where subject='maths'
		// List listofQuestions=session.createCriteria(Questions.class).add(Restrictions.eq("subject)

		HttpSession httpsession=request.getSession();
		httpsession.setAttribute("qno",0);
		httpsession.setAttribute("timeremaining", 121);

		Query query=session.createQuery("from Questions where subject=:subject ");
		query.setParameter("subject",selectedSubject);
		List<Questions> listOfQuestions=query.list();

		modelAndView.setViewName("questions");
		modelAndView.addObject("listOfQuestions",listOfQuestions);

		modelAndView.addObject("questions",listOfQuestions.get(0));//here questions is attribute name which represent questions,class object which is therein questions.jsppage
		httpsession.setAttribute("allquestions", listOfQuestions);

		HashMap<Integer,Answer> hashmap =new HashMap<>();
		httpsession.setAttribute("submittedDetails", hashmap);

		httpsession.setAttribute("score", 0);
		httpsession.setAttribute("subject", selectedSubject);

	}

	return modelAndView;
}

}

