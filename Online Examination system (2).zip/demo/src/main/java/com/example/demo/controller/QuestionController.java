package com.example.demo.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Answer;
import com.example.demo.entity.Questions;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class QuestionController {


	@RequestMapping("saveResponse")
	public void saveResponse(@ModelAttribute("answer") Answer answer,HttpServletRequest request,HttpServletResponse response)
	{
		System.out.println(answer);

		HttpSession httpsession=request.getSession();

		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");

		Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));

		String originalAnswer =question.getAnswer();
		


		System.out.println(originalAnswer);

		answer.setOriginalAnswer(originalAnswer);

		HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");
		hashmap.put(answer.qno, answer);
		System.out.println(httpsession.getAttribute("submittedDetails"));
	}

//	@Autowired SessionFactory factory;
//
	@RequestMapping("endexam")
	public ModelAndView endexam(HttpServletRequest request)
	{
		HttpSession httpsession=request.getSession();
		HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>)httpsession.getAttribute("submittedDetails");

		ModelAndView mv=new ModelAndView();
		mv.setViewName("score");

		if(hashmap!=null) {


			Collection<Answer> collection=hashmap.values();


		for(Answer answer: collection) {
		    System.out.println("Original Answer: " + answer.originalAnswer);
		    System.out.println("Submitted Answer: " + answer.submittedAnswer);


				if(answer.originalAnswer.equals(answer.submittedAnswer)) {
					httpsession.setAttribute("score", (Integer)httpsession.getAttribute("score")+1);

				}

				}

	//	mv.addObject("score",httpsession.getAttribute("score"));
	//	mv.addObject("allanswers", collection);

		httpsession.setAttribute("allanswers", collection);

		httpsession.removeAttribute("submittedDetails");

	}
		return mv;

}
	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request)
	{
		ModelAndView modelAndView = new ModelAndView();



		HttpSession httpsession=request.getSession();

		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");

		if((int)httpsession.getAttribute("qno")<=listofquestions.size()-2) { // listofquestions,size()-2 is used todisplay quetions till last question soit doesnt thow ecxeptin index out of found


		httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")+1);

		Questions questions=listofquestions.get((int)httpsession.getAttribute("qno"));

		int qno=questions.getqno();

		HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");

		Answer answer =hashmap.get(qno);

		String previousAnswer="";
		if(answer!=null) {
			previousAnswer=answer.submittedAnswer;
		}
		modelAndView.setViewName("questions");
		modelAndView.addObject("questions",questions);

		modelAndView.addObject("previousAnswer",previousAnswer);
		}
		else
		{

			modelAndView.setViewName("questions");
			modelAndView.addObject("questions",listofquestions.get(listofquestions.size()-1));// listofquestion.size()-1 is used to display msg questions over at last question if u press button next
			modelAndView.addObject("message","questions over");
			}

		return modelAndView;
	}



	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request)
	{
		ModelAndView modelAndView = new ModelAndView();

		HttpSession httpsession=request.getSession();

		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");

		if((int)httpsession.getAttribute("qno")>0) { // listofquestions,size()-2 is used todisplay quetions till last question soit doesnt thow ecxeptin index out of found


		httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")-1);

		Questions questions=listofquestions.get((int)httpsession.getAttribute("qno"));
		// code to retrieve previous answer
		int qno=questions.getqno();

		HashMap<Integer,Answer> hashmap=(HashMap<Integer,Answer>) httpsession.getAttribute("submittedDetails");

		Answer answer =hashmap.get(qno);

		String previousAnswer="";
		if(answer!=null) {
			previousAnswer=answer.submittedAnswer;
		}
		modelAndView.setViewName("questions");

		modelAndView.addObject("questions",questions);

		modelAndView.addObject("previousAnswer",previousAnswer);
		}
		else
		{
			modelAndView.setViewName("questions");

		modelAndView.addObject("questions",listofquestions.get(0));// listofquestion.size()-1 is used to display msg questions over at last question if u press button next
			modelAndView.addObject("message","questions over");
			}

		return modelAndView;
	}



}

//			/* hibernate score in database */
//			Session hibernateSession = factory.openSession();
//				Transaction tx=hibernateSession.beginTransaction();
//
//				Score score=new Score();
//				score.setUsername((String)httpsession.getAttribute("username"));
//				score.setSubject((String)httpsession.getAttribute("subject"));
//				score.setMarks((Integer)httpsession.getAttribute("score"));
//
//		}


