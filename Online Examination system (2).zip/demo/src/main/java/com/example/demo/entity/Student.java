package com.example.demo.entity;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Student {
	@Id
	public String username;
	public String password;
	public long mobno;
	public String emailid;
	public String imagepath;
	public transient MultipartFile images; //multipartfile contains image details

	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username=username;
	}
	public String getpassword() {
		return password;
	}
	public void setpassword(String password) {
		this.password=password;
	}
	public long getmobno() {
		return mobno;
	}
	public void setmobno(long mobno) {
		this.mobno=mobno;
	}
	public String getemailid() {
		return emailid;
	}
	public void setemailid(String emailid) {
		this.emailid=emailid;
	}
	public String getimagepath() {
		return imagepath;
		}
	public void setimagepath(String imagepath) {
		this.imagepath=imagepath;
	}

	@Override
	public String toString() {
		return "Student(username "+ username +",password="+password +",mobno="+mobno +",emailid=" +emailid +")";
	}
	public Student() {
    }
	public Student(String username, String password, long mobno, String emailid, String imagepath) {
		super();
		this.username = username;
		this.password = password;
		this.mobno = mobno;
		this.emailid = emailid;
		this.imagepath = imagepath;

	}
}
